﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RestaurantMngt.Data;
using RestaurantMngt.Models;

namespace RestaurantMngt.Areas.RestMngt.Controllers
{
    [Area("RestMngt")]
    public class OrderDetailsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrderDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: RestMngt/OrderDetails
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.OrderDetails.Include(o => o.Customers).Include(o => o.Menus).Include(o => o.Payments);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: RestMngt/OrderDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderDetail = await _context.OrderDetails
                .Include(o => o.Customers)
                .Include(o => o.Menus)
                .Include(o => o.Payments)
                .FirstOrDefaultAsync(m => m.OrderDetailId == id);
            if (orderDetail == null)
            {
                return NotFound();
            }

            return View(orderDetail);
        }

        // GET: RestMngt/OrderDetails/Create
        public IActionResult Create()
        {
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName");
            ViewData["DishId"] = new SelectList(_context.Menus, "DishID", "DishName");
            ViewData["PaymentMethod"] = new SelectList(_context.Payments, "OrderDetailId", "PaymentMethods");
            return View();
        }

        // POST: RestMngt/OrderDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OrderDetailId,Quantity,DishPrice,CustomerId,DishId,PaymentMethod")] OrderDetail orderDetail)
        {
            if (ModelState.IsValid)
            {
                _context.Add(orderDetail);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "Address", orderDetail.CustomerId);
            ViewData["DishId"] = new SelectList(_context.Menus, "DishID", "DishName", orderDetail.DishId);
            ViewData["PaymentMethod"] = new SelectList(_context.Payments, "OrderDetailId", "PaymentMethods", orderDetail.PaymentMethod);
            return View(orderDetail);
        }

        // GET: RestMngt/OrderDetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderDetail = await _context.OrderDetails.FindAsync(id);
            if (orderDetail == null)
            {
                return NotFound();
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "Address", orderDetail.CustomerId);
            ViewData["DishId"] = new SelectList(_context.Menus, "DishID", "DishName", orderDetail.DishId);
            ViewData["PaymentMethod"] = new SelectList(_context.Payments, "OrderDetailId", "PaymentMethods", orderDetail.PaymentMethod);
            return View(orderDetail);
        }

        // POST: RestMngt/OrderDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("OrderDetailId,Quantity,DishPrice,CustomerId,DishId,PaymentMethod")] OrderDetail orderDetail)
        {
            if (id != orderDetail.OrderDetailId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(orderDetail);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderDetailExists(orderDetail.OrderDetailId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "Address", orderDetail.CustomerId);
            ViewData["DishId"] = new SelectList(_context.Menus, "DishID", "DishName", orderDetail.DishId);
            ViewData["PaymentMethod"] = new SelectList(_context.Payments, "OrderDetailId", "PaymentMethods", orderDetail.PaymentMethod);
            return View(orderDetail);
        }

        // GET: RestMngt/OrderDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderDetail = await _context.OrderDetails
                .Include(o => o.Customers)
                .Include(o => o.Menus)
                .Include(o => o.Payments)
                .FirstOrDefaultAsync(m => m.OrderDetailId == id);
            if (orderDetail == null)
            {
                return NotFound();
            }

            return View(orderDetail);
        }

        // POST: RestMngt/OrderDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var orderDetail = await _context.OrderDetails.FindAsync(id);
            _context.OrderDetails.Remove(orderDetail);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OrderDetailExists(int id)
        {
            return _context.OrderDetails.Any(e => e.OrderDetailId == id);
        }
    }
}
