﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RestaurantMngt.Models
{
    [Table(name: "MenuItems")]
    public class MenuItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int DishID { get; set; }

        [Required(ErrorMessage = "{0} cannot be empty!")]
        [Column(TypeName = "varchar(50)")]
        [Display(Name = "Name of the Dish")]
        public string DishName { get; set; }

        [Required]
        [DefaultValue(1)]
        virtual public short Quantity { get; set; }

        #region Navigation Properties to the Category Model
        [Display(Name = "Choose Category")]
        public int CategoryId { get; set; }


        [ForeignKey(nameof(MenuItem.CategoryId))]
        public Category Category { get; set; }
        #endregion


        #region Navigation Properties to the OrderDetails Model
        public ICollection<OrderDetail> OrderDetails { get; set; }
        #endregion
    }
}