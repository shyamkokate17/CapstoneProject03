﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;


namespace RestaurantMngt.Models
{
    [Table(name: "Customers")]
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int CustomerId { get; set; }

        [Required(ErrorMessage = "{0} cannot be empty!")]
        [Column(TypeName = "varchar(50)")]
        [Display(Name = "Customer Name")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage ="Please enter appropriate name...")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage ="{0} cannot be blank")]
        [Column(TypeName = "varchar(100)")]
        [Display(Name = "Customer Address")]

        public string Address { get; set; }

        [Required(ErrorMessage ="{0} required")]
        [Column(TypeName = "varchar(10)")]
        [Display(Name ="Phone Number")]
        public string PhoneNumber { get; set; }

        #region Navigation Properties to the OrderDetail Model
        public ICollection<OrderDetail> OrderDetails { get; set; }
        #endregion
    }
}