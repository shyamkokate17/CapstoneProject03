﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using RestaurantMngt.Models;

namespace RestaurantMngt.Models
{
    [Table(name: "OrderDetails")]

    public class OrderDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderDetailId { get; set; }

        [Required]
        [Display(Name = "Ordered Quantity")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "{0} cannot be empty!")]
        [Column(TypeName = "varchar(50)")]
        [Display(Name = "Price")]
        public int DishPrice { get; set; }

        [Display(Name = "Total Amount")]
        public int TotalAmount {
            get { 
                return Quantity * DishPrice;
            }
        }
        #region Navigation Properties to the Customer Model

        [Display(Name = "Customer Name")]
        public int CustomerId { get; set; }

        [ForeignKey(nameof(OrderDetail.CustomerId))]

        public Customer Customers { get; set; }

        #endregion

        #region Navigation Properties to the Menu Model

        [Display(Name = "Name of the Dish")]
        public int DishId { get; set; }
        [ForeignKey(nameof(OrderDetail.DishId))]
        public MenuItem Menus { get; set; }

        #endregion

        #region Navigation Properties to the Payment Model

        [Display(Name = "Payment Options")]
        public int PaymentMethod { get; set; }
        [ForeignKey(nameof(OrderDetail.PaymentMethod))]
        public Payment Payments { get; set; }


        #endregion
    }
}
